<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Ventas;
use App\Models\Productos;
use App\Models\Usuarios;
use PDF;
use App\Exports\ProductsExport;
use App\Exports\ServicesExport;
use Maatwebsite\Excel\Facades\Excel;

class GeneradorController extends Controller
{
    public function imprimir(){
        $today = Carbon::now()->format('d/m/Y');
        $pdf = \PDF::loadView('pdf', compact('today')); 
        return $pdf->download('pdf.pdf');
      }
    public function factura($id_venta){
       $id = session('session_id');
        $usu1 = Usuarios::find($id);
        
        if( is_null($usu1)){
            abort(404);
        } 
        $ven = Ventas::find($id_venta);
        $prod = Productos::all();
        $today = Carbon::now()->format('d/m/Y');
         
    
        $pdf = \PDF::loadView('pdf', compact('ven','prod','usu1','today'));
        return $pdf->download('pdf.pdf');
      }

    public function exportar(){
        return Excel::download(new ProductsExport, 'Productos.xlsx');
    }

     public function exportar2(){
        return Excel::download(new ServicesExport, 'Servicios.xlsx');
    }
//--------- pruebas ----------
    public function excel(){
      $prod = Productos::all();
      return view('excel')
      ->with(['prod'=>$prod]); 
    }
}
