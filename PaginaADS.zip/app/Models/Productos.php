<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Productos extends Model
{
    use HasFactory;
    protected $table = "tb_productos" ;
    //protected $primarykey = "id";
  protected $fillable = [
      'foto',
      'foto2',
      'foto3',
      'foto4',
      'nombre',
      'precio',
      'descripcion',
      'id_tabla'
     
  ];

  public function scopeBuscar($query, $buscar){
    if(trim($buscar) != ""){
        $query->where(\DB::raw('nombre'), "LIKE", "%".$buscar."%");
    }
}
}
